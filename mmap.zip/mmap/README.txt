README for mmap

Name: Alex "Spot" Kasemir

Aspects: The project is complete. The distances of all of the characters can 
	 seen in the info window for my own post.

Discussed: alone

Hours: 6 hours


